using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SellButtonManager : MonoBehaviour
{
    public GameObject ChocolateBar;
    public GameObject GummyBear;
    public GameObject Donut;
    public GameObject Lollipop;
    public GameObject CandyCane;
    public GameObject Strawberry;
    public GameObject GingerBread;
    public GameObject CakePop;
    public GameObject Brownie;

    private int ChocolateBarPrice = 10;
    private int GummyBearPrice = 5;
    private int DonutPrice = 15;
    private int LollipopPrice = 5;
    private int CandyCanePrice = 10;
    private int StrawberryPrice = 5;
    private int GingerBreadPrice = 20;
    private int CakePopPrice = 15;
    private int BrowniePrice = 20;

   public MoneySystem moneySystem;
    public LayerMask layerMask;
    public float raycastDistance = 1.0f;
    void Update()
    {
        
    }

    private void Start()
    {
        
    }

    public void Sell()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.up, raycastDistance, layerMask);

        if (hit.collider != null)
        {
            GameObject objectAboveButton = hit.collider.gameObject;
            Destroy(objectAboveButton);
            Debug.Log("Object aboce button:" + objectAboveButton);


            if (objectAboveButton.name == "GummyBear(Clone)")
            {
                moneySystem.money += GummyBearPrice;
                moneySystem.UpdateMoneyText();
            }
            if (objectAboveButton.name == "ChocolateBar(Clone)") 
            {
               moneySystem.money += ChocolateBarPrice;
               moneySystem.UpdateMoneyText();
            }
            if (objectAboveButton.name == "Donut(Clone)")
            {
                moneySystem.money += DonutPrice;
                moneySystem.UpdateMoneyText();
            }
            if (objectAboveButton.name == "Lollipop(Clone)")
            {
                moneySystem.money += LollipopPrice;
                moneySystem.UpdateMoneyText();
            }
            if (objectAboveButton.name == "CandyCane(Clone)")
            {
                moneySystem.money += CandyCanePrice;
                moneySystem.UpdateMoneyText();
            }
            if (objectAboveButton.name == "Strawberry(Clone)")
            {
                moneySystem.money += StrawberryPrice;
                moneySystem.UpdateMoneyText();
            }
            if (objectAboveButton.name == "GingerBread(Clone)")
            {
                moneySystem.money +=  GingerBreadPrice;
                moneySystem.UpdateMoneyText();
            }
            if (objectAboveButton.name == "CakePop(Clone)")
            {
                moneySystem.money += CakePopPrice;
                moneySystem.UpdateMoneyText();
            }
            if (objectAboveButton.name == "Brownie(Clone)")
            {
                moneySystem.money += BrowniePrice;
                moneySystem.UpdateMoneyText();
            }


        }
        else
        {
            Debug.Log("No object");
        }

        
    }
}
