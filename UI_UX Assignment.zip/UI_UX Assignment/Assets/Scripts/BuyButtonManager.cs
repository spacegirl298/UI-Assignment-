using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuyButtonManager : MonoBehaviour
{
    public Transform[] Slots;
    public MoneySystem moneySystem;
    public GameObject ChocolateBar;
    public GameObject GummyBear;
    public GameObject Donut;
    public GameObject Lollipop;
    public GameObject CandyCane;
    public GameObject Strawberry;
    public GameObject GingerBread;
    public GameObject CakePop;
    public GameObject Brownie;

    public Transform StorageSlot;

    public Vector3 sizes = new Vector3(70f, 70f, 0);

    private int Lastpoint = -1;

    public void Buy1()
    {

        if (moneySystem.money >= moneySystem.ChocolatePrice)
        {
            int startIndex = Lastpoint + 1;

            if (startIndex >= Slots.Length)
            {
                startIndex = 0;
            }

            for (int i = startIndex; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(ChocolateBar, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton1();

                    return;

                }
            }
            for (int i = 0; i < startIndex; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(ChocolateBar, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;

                    moneySystem.DeductButton1();

                    return;
                }


            }
        }
    }

    public void Buy2()
    {

        if (moneySystem.money >= moneySystem.GummyBearPrice)
        {
            int startIndex = Lastpoint + 1;

            if (startIndex >= Slots.Length)
            {
                startIndex = 0;
            }

            for (int i = startIndex; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(GummyBear, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);


                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton2();

                    return;

                }
            }
            for (int i = 0; i < startIndex; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(GummyBear, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton2();


                    return;
                }


            }
        }
    }

    public void Buy3()
    {

        if (moneySystem.money >= moneySystem.DonutPrice)
        {
            int startIndex = Lastpoint + 1;

            if (startIndex >= Slots.Length)
            {
                startIndex = 0;
            }

            for (int i = startIndex; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(Donut, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.1f, 0);


                    CloneObject.transform.localScale = new Vector3(50, 50, 0);

                    Lastpoint = i;
                    moneySystem.DeductButton3();

                    return;

                }
            }
            for (int i = 0; i < startIndex; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(Donut, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.1f, 0);

                    CloneObject.transform.localScale = new Vector3(50, 50, 0);

                    Lastpoint = i;
                    moneySystem.DeductButton3();


                    return;
                }


            }
        }
    }

    public void Buy4()
    {

        if (moneySystem.money >= moneySystem.LollipopPrice)
        {
            int startIndex = Lastpoint + 1;

            if (startIndex >= Slots.Length)
            {
                startIndex = 0;
            }

            for (int i = startIndex; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(Lollipop, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);


                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton4();

                    return;

                }
            }
            for (int i = 0; i < startIndex; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(Lollipop, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);

                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton4();


                    return;
                }


            }
        }
    }

    public void Buy5()
    {

        if (moneySystem.money >= moneySystem.CandyCanePrice)
        {
            int startIndex = Lastpoint + 1;

            if (startIndex >= Slots.Length)
            {
                startIndex = 0;
            }

            for (int i = startIndex; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(CandyCane, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);


                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton5();

                    return;

                }
            }
            for (int i = 0; i < startIndex; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(CandyCane, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);

                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton5();


                    return;
                }


            }
        }
    }

    public void Buy6()
    {

        if (moneySystem.money >= moneySystem.StrawberryPrice)
        {
            int startIndex = Lastpoint + 1;

            if (startIndex >= Slots.Length)
            {
                startIndex = 0;
            }

            for (int i = startIndex; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(Strawberry, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.2f, 0);


                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton6();

                    return;

                }
            }
            for (int i = 0; i < startIndex; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(Strawberry, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.2f, 0);

                    CloneObject.transform.localScale = new Vector3(200, 200, 0);

                    Lastpoint = i;
                    moneySystem.DeductButton6();


                    return;
                }


            }
        }
    }

    public void Buy7()
    {

        if (moneySystem.money >= moneySystem.GingerBreadPrice)
        {
            int startIndex = Lastpoint + 1;

            if (startIndex >= Slots.Length)
            {
                startIndex = 0;
            }

            for (int i = startIndex; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(GingerBread, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);


                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton7();

                    return;

                }
            }
            for (int i = 0; i < startIndex; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(GingerBread, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);

                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton7();


                    return;
                }


            }
        }
    }
    public void Buy8()
    {

        if (moneySystem.money >= moneySystem.CakePopPrice)
        {
            int startIndex = Lastpoint + 1;

            if (startIndex >= Slots.Length)
            {
                startIndex = 0;
            }

            for (int i = startIndex; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(CakePop, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.4f, 0);


                    CloneObject.transform.localScale = new Vector3(40, 40, 0) ;

                    Lastpoint = i;
                    moneySystem.DeductButton8();

                    return;

                }
            }
            for (int i = 0; i < startIndex; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(CakePop, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.4f, 0);

                    CloneObject.transform.localScale = new Vector3(40, 40, 0);

                    Lastpoint = i;
                    moneySystem.DeductButton8();


                    return;
                }


            }
        }
    }

    public void Buy9()
    {

        if (moneySystem.money >= moneySystem.BrowniePrice)
        {
            int startIndex = Lastpoint + 1;

            if (startIndex >= Slots.Length)
            {
                startIndex = 0;
            }

            for (int i = startIndex; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(Brownie, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);


                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton9();

                    return;

                }
            }
            for (int i = 0; i < startIndex; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    GameObject CloneObject = Instantiate(Brownie, space.position, Quaternion.identity, StorageSlot);
                    CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                    CloneObject.transform.localScale = sizes;

                    Lastpoint = i;
                    moneySystem.DeductButton9();


                    return;
                }


            }
        }
    }
}
        

