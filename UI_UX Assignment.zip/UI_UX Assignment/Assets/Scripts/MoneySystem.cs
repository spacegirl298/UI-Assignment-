using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class MoneySystem : MonoBehaviour
{
    public int money = 100;
    public Text moneyText;

    public int ChocolatePrice = 10;
    public int GummyBearPrice = 5;
    public int DonutPrice = 15;
    public int LollipopPrice = 5;
    public int CandyCanePrice = 10;
    public int StrawberryPrice = 5;
    public int GingerBreadPrice = 20;
    public int CakePopPrice = 15;
    public int BrowniePrice = 20;

    public Transform boxAboveButton;
    private void Start()
    {
        UpdateMoneyText();
    }

   public  void UpdateMoneyText()
    {
        moneyText.text = "Money: $" + money.ToString();
    }

    public void DeductButton1()
    {
       if (money >= 10)
        {
            money -= ChocolatePrice;
            UpdateMoneyText();
        }

        
    }

    public void DeductButton2()
    {
        if (money >= 5)
        {
            money -= GummyBearPrice;
            UpdateMoneyText();
        }
        
    }

    public void DeductButton3()
    {
        if (money >= 15)
        {
            money -= DonutPrice;
            UpdateMoneyText();
        }

    }

    public void DeductButton4()
    {
        if (money >= 5)
        {
            money -= LollipopPrice;
            UpdateMoneyText();
        }
    }

    public void DeductButton5()
    {
        if (money >= 10)
        {
            money -= CandyCanePrice;
            UpdateMoneyText();
        }
    }

    public void DeductButton6()
    {
        if (money >= 5)
        {
            money -= StrawberryPrice;
            UpdateMoneyText();
        }
    }

    public void DeductButton7()
    {
        if (money >= 20)
        {
            money -= GingerBreadPrice;
            UpdateMoneyText();
        }
    }

    public void DeductButton8()
    {
        if (money >= 15)
        {
            money -= CakePopPrice;
            UpdateMoneyText();
        }
    }
    public void DeductButton9()
    {
        if (money >= 20)
        {
            money -= BrowniePrice;
            UpdateMoneyText();
        }
    }

   public void ChocolateBarSell()
    {
        money += ChocolatePrice;
        UpdateMoneyText();
    }

   public void GummyBearSell()
    {
        money += GummyBearPrice;
        UpdateMoneyText();
    }

    public void DonutSell()
    { 
        money += DonutPrice;
        UpdateMoneyText();
    }

    public void LollipopSell()
    { 
        money += LollipopPrice;
        UpdateMoneyText();
    }

    public void CandyCaneSell()
    {
        money += CandyCanePrice;
        UpdateMoneyText();
    }

    public void StrawberrySell()
    {
        money += StrawberryPrice;
        UpdateMoneyText();
    }

    public void GingerBreadSell()
    {
        money += GingerBreadPrice;
        UpdateMoneyText();
    }

    public void CakePopSell()
    {
        money += CakePopPrice;
        UpdateMoneyText();
    }

    public void BrownieSell()
    {
        money += BrowniePrice;
        UpdateMoneyText();
    }
  



}