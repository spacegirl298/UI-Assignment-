using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackPackButtonManager : MonoBehaviour
{
    public Transform[] Slots;
    public Transform BackPackSlot;

    public Vector3 sizes = new Vector3(70f, 70f, 0);

    private int Lastpoint = -1;

    public LayerMask layerMask;
    public float raycastDistance = 1.0f;

    public GameObject ChocolateBar;
    public GameObject GummyBear;
    public GameObject Donut;
    public GameObject Lollipop;
    public GameObject CandyCane;
    public GameObject Strawberry;
    public GameObject GingerBread;
    public GameObject CakePop;
    public GameObject Brownie;
    public void BackPack()
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.up, raycastDistance, layerMask);

        if (hit.collider != null)
        {
            GameObject objectBelowButton = hit.collider.gameObject;

            Debug.Log("Object below button:" + objectBelowButton);




            int startIndex = Lastpoint + 1;

            if (startIndex >= Slots.Length)
            {
                startIndex = 0;
            }

            for (int i = startIndex; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    if (objectBelowButton.name == "ChocolateBar(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(ChocolateBar, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "GummyBear(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(GummyBear, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "Donut(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(Donut, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.1f, 0);

                        CloneObject.transform.localScale = new Vector3(50, 50, 0);

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "Lollipop(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(Lollipop, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "CandyCane(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(CandyCane, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "Strawberry(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(Strawberry, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.2f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "GingerBread(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(GingerBread, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "CakePop(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(CakePop, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.4f, 0);

                        CloneObject.transform.localScale = new Vector3(40, 40, 0);

                        Lastpoint = i;
                    }
                    if (objectBelowButton.name == "Brownie(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(Brownie, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    return;

                }
            }
            for (int i = 0; i < startIndex; i++)
            {
                Transform space = Slots[i];

                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {

                    if (objectBelowButton.name == "ChocolateBar(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(ChocolateBar, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "GummyBear(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(GummyBear, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "Donut(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(Donut, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.1f, 0);

                        CloneObject.transform.localScale = new Vector3(50, 50, 0);

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "Lollipop(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(Lollipop, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "CandyCane(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(CandyCane, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "Strawberry(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(Strawberry, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.2f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "GingerBread(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(GingerBread, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.5f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }

                    if (objectBelowButton.name == "CakePop(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(CakePop, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.4f, 0);

                        CloneObject.transform.localScale = new Vector3(40, 40, 0);

                        Lastpoint = i;
                    }
                    if (objectBelowButton.name == "Brownie(Clone)")
                    {
                        Destroy(objectBelowButton);
                        GameObject CloneObject = Instantiate(Brownie, space.position, Quaternion.identity, BackPackSlot);
                        CloneObject.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                        CloneObject.transform.localScale = sizes;

                        Lastpoint = i;
                    }


                    return;
                }

            }



        }



    }
}




