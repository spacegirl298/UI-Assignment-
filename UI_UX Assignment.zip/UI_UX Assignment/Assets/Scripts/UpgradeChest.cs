using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpgradeChest : MonoBehaviour
{

    public void Start()
    {
    }
    public void ActivatBlock()
    {
    }
}
