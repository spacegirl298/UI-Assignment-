using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Reorganising : MonoBehaviour

{
    public Transform[] Slots; // Array of slots where objects can be placed
    public LayerMask layerMask; // Layer mask for raycast
    public float raycastDistance = 1f; // Distance for raycast
    public Transform ChestSlot; // Parent transform for instantiated objects
    public Vector3 sizes; // Sizes for scaling


    public ChestButton ChestButton;
    public Text ReorganiseText;

    private int Lastpoint = 0; // Index of the last point where an object was placed

    public void Start()
    {
        ChestButton.isTrue = false;
        ReorganiseText.enabled = false;
    }

        // Method to reshuffle objects
        public void ReshuffleObjects()
    {
        if (ChestButton.isTrue == true)
        {
            ReorganiseText.enabled = false;
            // Iterate through each slot in the array
            for (int i = 0; i < Slots.Length; i++)
            {
                Transform space = Slots[i];

                // Check if the current slot is available (no colliders)
                Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                if (colliders.Length == 0)
                {
                    // Check if there is an object below the button
                    RaycastHit2D hit = Physics2D.Raycast(transform.position, Vector2.down, raycastDistance, layerMask);
                    if (hit.collider != null)
                    {
                        // Get the object below the button
                        GameObject objectBelowButton = hit.collider.gameObject;

                        // Move the object to the current empty slot
                        objectBelowButton.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                        // Update Lastpoint index
                        Lastpoint = i;
                    }
                    return; // Exit the loop after moving one object
                }
            }
        }
        else
        {
            ReorganiseText.enabled = true;
        }
    }
}
/*
public Transform[] Slots; // Array of slots where objects can be placed
public Text ReorganiseText;
public LayerMask layerMask; // Layer mask for raycast
public float raycastDistance = 1f; // Distance for raycast
public Transform ChestSlot; // Parent transform for instantiated objects
public Transform ChestSlot2;
public Vector3 sizes; // Sizes for scaling
public ChestButton ChestButton;

private bool[] slotOccupied; // Array to keep track of occupied slots
private int Lastpoint = 1; // Index of the last point where an object was placed

// Method to reshuffle objects
public void Start()
{
    ChestButton.isTrue = false;
    ReorganiseText.enabled = false;

    // Initialize the slotOccupied array with the length of Slots array
    slotOccupied = new bool[Slots.Length];
}

public void ReshuffleObjects()
{
    if (ChestButton.isTrue == true)
    {
        ReorganiseText.enabled = false;
        // Define angles for raycasts
        float[] angles = { 0f, 45f, 90f, 135f, 180f, 225f, 270f, 315f };

        // Iterate through each angle
        foreach (float angle in angles)
        {
            // Cast ray from the button position at the specified angle
            Vector2 direction = Quaternion.Euler(0f, 0f, angle) * Vector2.down;
            RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, raycastDistance, layerMask);

            if (hit.collider != null)
            {
                // Get the object below the button
                GameObject objectBelowButton = hit.collider.gameObject;

                // Iterate through each slot in the array
                for (int i = 0; i < Slots.Length; i++)
                {
                    // Check if the current slot is available (no colliders)
                    if (!slotOccupied[i])
                    {
                        // Move the object to the current empty slot
                        objectBelowButton.transform.position = new Vector3(Slots[i].position.x, Slots[i].position.y - 0.3f, 0);

                        // Update Lastpoint index
                        Lastpoint = i;

                        // Mark the slot as occupied
                        slotOccupied[i] = true;
                        break; // Exit the loop after moving the object
                    }
                }
            }
        }
    }
    else
    {
        ReorganiseText.enabled = true;
    }
}
}


public Transform[] Slots; // Array of slots where objects can be placed
public Text ReorganiseText;
public LayerMask layerMask; // Layer mask for raycast
public float raycastDistance = 15f; // Distance for raycast
public Transform ChestSlot; // Parent transform for instantiated objects
public Transform ChestSlot2;
public Vector3 sizes; // Sizes for scaling
public ChestButton ChestButton;

private int Lastpoint = 1; // Index of the last point where an object was placed

// Method to reshuffle objects
public void Start()
{
    ChestButton.isTrue = false;
    ReorganiseText.enabled = false;
}

public void ReshuffleObjects()
{
    if (ChestButton.isTrue == true)
    {
        ReorganiseText.enabled = false;
        // Define angles for raycasts
        float[] angles = { 0f, 45f, 90f, 135f, 180f, 225f, 270f, 315f };

        // Iterate through each angle
        foreach (float angle in angles)
        {
            // Cast ray from the button position at the specified angle
            Vector2 direction = Quaternion.Euler(0f, 0f, angle) * Vector2.down;
            RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, raycastDistance, layerMask);

            if (hit.collider != null)
            {
                // Get the object below the button
                GameObject objectBelowButton = hit.collider.gameObject;

                // Iterate through each slot in the array
                foreach (Transform space in Slots)
                {
                    // Check if the current slot is available (no colliders)
                    Collider2D[] colliders = Physics2D.OverlapPointAll(space.position);

                    if (colliders.Length == 0)
                    {
                        // Move the object to the current empty slot
                        objectBelowButton.transform.position = new Vector3(space.position.x, space.position.y - 0.3f, 0);

                        // Update Lastpoint index
                        Lastpoint = space.GetSiblingIndex();
                        break; // Exit the loop after moving the object
                    }
                }
            }
        }
    }
    else
    {
        ReorganiseText.enabled = true;
    }
}

}*/









